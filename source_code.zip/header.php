<header>
    <nav>
        <ul>
            <li><a href="add_article.php">Ajouter un article</a></li>
            <li><a href="liste_article.php">Liste article</a></li>
            <li><a href="deconnexion.php">Se déconnecter</a></li>
        </ul>
    </nav>
</header>